require("dotenv").config({
  path: require("path").resolve(__dirname, "../.env")
});

const express = require("express");
const cors = require("cors");
const pool = require("./db");

const app = express();
const PORT = process.env.PORT || 5000;

// Allow requests from your frontend during development
app.use(cors());
app.use(express.json());

// Basic check that the backend is running
app.get("/api/health", (req, res) => {
  res.json({ message: "CivicFix backend is running" });
});

// Check that the backend can reach Supabase
app.get("/api/db-health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ message: "Supabase database connected" });
  } catch (error) {
    console.error("Database connection error:", error.message);
    res.status(500).json({ error: "Could not connect to the database" });
  }
});

// Issues API routes
app.use("/api/issues", require("./routes/issues"));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Backend running on port ${PORT}`);
});